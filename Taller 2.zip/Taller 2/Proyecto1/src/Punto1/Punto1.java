package Punto1;
public class Punto1 {
    public static void main(String[] args) {
        int x = 10;
        double z = x;
        System.out.printf("x = %d\n", x ); 
        System.out.printf("El valor de %d + %d es %d\n", x, x, ( x + x ) );
        System.out.printf("El valor de %d / 2 = %.2f\n", x, (z/2));
        System.out.printf("El valor de %d mod 3 = %d\n", x, x%3 );
    }
    

    }


    
    