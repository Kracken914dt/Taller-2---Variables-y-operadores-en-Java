package punto2;

public class Punto2 {
    public static void main(String[] args) {
        double num1 = 24;
        double num2 = 46;
        double num3 = 18;
        
        double suma = (num1 + num2 + num3);
        double promedio = suma/3;
        double cociente = num1 / num2 / num3;
        double producto = num1 * num2 * num3;
        double Modulo = num1 % num2 % num3;
       
        System.out.printf("El resultado de la suma es: %.2f\n",suma);
        System.out.printf("El promedio  es: %.2f\n",promedio);
        System.out.printf("El cociente es: %.2f\n",cociente);
        System.out.printf("El producto es: %.2f\n",producto);
        System.out.printf("El Modulo es: %.2f\n",Modulo);
    }
    
}
