package Punto3;
public class Punto3 {
    public static void main(String[] args) {
        int Valorcosto = 100000;
    int iva = 10;
    int porceutilidad = 25;
    int cobroiva = (Valorcosto*iva/100);
    int utilidad = (porceutilidad*25/100);
    int total = cobroiva+utilidad+Valorcosto;
    System.out.println("El total de ventas es: " + total);
        
            
            
    }
 
}
