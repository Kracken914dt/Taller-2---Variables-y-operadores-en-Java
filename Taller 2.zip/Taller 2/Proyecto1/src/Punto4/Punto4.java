package Punto4;
public class Punto4 {
    public static void main(String[] args) {
        int Numero_dias_viaje = 12;
        int TotalKm_Dia = 100;
        int CostoLtGaso = 20000;
        int Cuantoslitros = 5;
        int Costototalde_Litros = Cuantoslitros * CostoLtGaso;
        double promedioKmporLt =TotalKm_Dia / Cuantoslitros ;
        int PagoEstacioDia = 6000;
        int Pagopeaje = 8000;
        int costototalv = Pagopeaje + PagoEstacioDia + Costototalde_Litros;
        int TotalGasto = costototalv * Numero_dias_viaje;
        System.out.println("El gasto total del viaje es:"+TotalGasto);
        System.out.println("Kilometro por Litro es: "+promedioKmporLt);
        
        
    }
    
}
