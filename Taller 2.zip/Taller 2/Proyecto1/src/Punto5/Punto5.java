package Punto5;
public class Punto5 {
    public static void main(String[] args) {
        int Manzana = 52;
        int Piña = 55;
        int Pera = 55;
        int Naranja = 45;
        int Fresas = 32;
        int Melon = 54;
        // Calculo
      int Calculo1 = Manzana * 2;
      int Calculo2 = Pera * 3;
      int Calculo3 = Naranja * 1;  
      int Calculo4 = Melon * 1;
      int suma = Calculo1 + Calculo2 + Calculo3 + Calculo4;
        System.out.println("El total de calorias consumidas es: "+suma+" Kcal");
    }
}
